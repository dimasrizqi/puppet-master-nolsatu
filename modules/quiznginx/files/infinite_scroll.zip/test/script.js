$(window).resize(function(){
    resizeBox();
});

$(".box").on("mouseenter", function(){    
    var img = `url('img/${Math.ceil(Math.random()*7)}.jpg')`;
    this.style.backgroundImage = img;
});

$(".box").on("click", function(){
    var box = $("<div class='parent'>")
                .append($("<div>",{
                    class: 'box',
                    style: 'background-image: url("img/5.jpg")'
                }));
    $("body").append(box);
});

//functions
// var box = '<div class="parent"><div class="box" style="background-image=url(img/1.jpg)"></div></div>';
var box = $("<div class='parent'>").append($("<div class='box'>"));

function resizeBox(){
    $(".box").html($(".box").width());
    $(".box").height($(".box").width());
}

function randImage(){
    for (let i = 0; i < $(".box").length; i++) {
        $(".box")[i].style.backgroundImage = `url('img/${Math.ceil(Math.random()*7)}.jpg')`;
    }
}

function generateBox(){
    
}

//onload
resizeBox();
randImage();